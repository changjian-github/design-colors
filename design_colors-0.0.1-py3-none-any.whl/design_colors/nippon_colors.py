ai = "#0D5661"
aikobicha = "#4B4E2A"
aimirucha = "#0F4C3A"
ainezumi = "#566C73"
aisumicha = "#373C38"
akabeni = "#CB4042"
akakoh = "#E3916E"
akakuchiba = "#C78550"
akashirotsurubami = "#E1A679"
ake = "#CC543A"
akebono = "#F19483"
aku = "#877F6C"
aokuchiba = "#ADA142"
aomidori = "#00AA90"
aoni = "#516E41"
aonibi = "#535953"
aotake = "#00896C"
araigaki = "#E79460"
araisyu = "#FB966E"
asagi = "#33A6B8"
ayame = "#6F3381"
azuki = "#954A45"
baikocha = "#89916B"
bengara = "#9A5034"
benifuji = "#B481BB"
benihi = "#F75C2F"
benihiwada = "#884C3A"
benikaba = "#B54434"
benikakehana = "#4E4F97"
benikeshinezumi = "#52433D"
benimidori = "#7B90D2"
benitobi = "#994639"
beniukon = "#E98B2A"
binrojizome = "#3A3226"
biwacha = "#B17844"
botan = "#C1328E"
budohnezumi = "#5E3D50"
byakugun = "#78C2C4"
byakuroku = "#A8D8B9"
chigusa = "#3A8FB7"
chitosemidori = "#36563C"
chojicha = "#96632E"
chojizome = "#B07736"
cyohsyun = "#BF6766"
dobunezumi = "#4F4F48"
ebicha = "#734338"
ebizome = "#6D2E5B"
edocha = "#AF5F3C"
edomurasaki = "#77428D"
enji = "#9F353A"
ensyucha = "#CA7853"
entan = "#D75455"
fuji = "#8B81C3"
fujimurasaki = "#8A6BBE"
fujinezumi = "#6E75A4"
fujisusutake = "#574C57"
fukagawanezumi = "#77969A"
fushizome = "#967249"
futaai = "#70649A"
ginnezumi = "#91989F"
ginsusutake = "#82663A"
ginsyu = "#C73E3A"
gofun = "#FFFFFB"
gunjyo = "#51A8DD"
hai = "#828282"
haizakura = "#D7C4BB"
hajizome = "#DDA52D"
hanaasagi = "#1E88A8"
hanaba = "#F7C242"
hanada = "#006284"
hashita = "#986DB2"
hatobanezumi = "#72636E"
higosusutake = "#8D742A"
hiwa = "#BEC23F"
hiwacha = "#A5A051"
hiwada = "#854836"
hiwamoegi = "#90B44B"
ichigo = "#B5495B"
ikkonzome = "#F4A7B9"
imayoh = "#D05A6E"
iwaicha = "#646A58"
jinzamomi = "#EB7A77"
kaba = "#C1693C"
kabacha = "#B35C37"
kachi = "#08192D"
kakishibu = "#A35E47"
kakitsubata = "#622954"
kamenozoki = "#A5DEE4"
kanzo = "#FC9F4D"
karacha = "#B47157"
karakurenai = "#D0104C"
karashi = "#CAAD5F"
kariyasu = "#E9CD4C"
kenpohzome = "#43341B"
keshizumi = "#434343"
kigaracha = "#C18A26"
kihada = "#FBE251"
kikuchiba = "#D9AB42"
kikujin = "#B1B479"
kikyo = "#6A4C9C"
kimirucha = "#867835"
kincha = "#C7802D"
kitsune = "#9B6E23"
kitsurubami = "#BA9132"
kobicha = "#876633"
kogecha = "#563F2E"
kohaku = "#CA7A2C"
kohbai = "#E16B8C"
kohrozen = "#7D532C"
koke = "#838A2D"
kokiake = "#86473F"
kokikuchinashi = "#FB9966"
kokimurasaki = "#4A225D"
kon = "#0F2540"
konjyo = "#113285"
konkikyo = "#211E55"
korainando = "#305A56"
kuchiba = "#E2943B"
kuchinashi = "#F6C555"
kurenai = "#CB1B45"
kurikawacha = "#6A4028"
kuriume = "#904840"
kuro = "#080808"
kurobeni = "#3F2B36"
kurotobi = "#554236"
kurotsurubami = "#0B1013"
kurumi = "#947A6D"
kuwacha = "#C99833"
kuwazome = "#64363C"
kyara = "#78552B"
masuhana = "#577C8A"
matsuba = "#42602D"
messhi = "#533D5B"
midori = "#227D51"
miru = "#5B622E"
mirucha = "#62592C"
mizu = "#81C7D4"
mizuasagi = "#66BAB7"
mizugaki = "#B9887D"
moegi = "#7BA23F"
momo = "#F596AA"
momoshiocha = "#724938"
murasaki = "#592C63"
murasakitobi = "#60373E"
mushiao = "#20604F"
mushikuri = "#D9CD90"
nadeshiko = "#DC9FB4"
nae = "#86C166"
nakabeni = "#DB4D6D"
namakabe = "#7D6C46"
namari = "#787878"
nanohana = "#F7D94C"
nasukon = "#572A3F"
nataneyu = "#A28C37"
nibi = "#656765"
nisemurasaki = "#562E37"
noshimehana = "#2B5F75"
ohdo = "#B68E55"
ohni = "#F05E1C"
oitake = "#6A8372"
omeshicha = "#376B6D"
omeshionando = "#2E5C6E"
ominaeshi = "#DDD23B"
onando = "#0C4842"
onandocha = "#465D4C"
ouchi = "#9B90C2"
rikancha = "#616138"
rikyucha = "#897D55"
rikyunezumi = "#707C74"
rikyushiracha = "#B4A582"
ro = "#0C0C0C"
rokohcha = "#74673E"
rokusyoh = "#24936E"
ruri = "#005CAF"
rurikon = "#0B346E"
sabiasagi = "#6699A1"
sabionando = "#336774"
sabiseiji = "#86A697"
sabitetsuonando = "#405B55"
sakura = "#FEDFE1"
sakuranezumi = "#B19693"
sangosyu = "#F17C67"
seiheki = "#268785"
seiji = "#69B0AC"
sencha = "#855B32"
sensaicha = "#4D5139"
sharegaki = "#FFBA84"
shikancha = "#B55D4C"
shikon = "#3C2F41"
shinbashi = "#0089A7"
shinsyu = "#AB3B3A"
shion = "#8F77B5"
shiracha = "#BC9F77"
shironeri = "#FCFAF2"
shironezumi = "#BDC0BA"
shirotsurubami = "#DCB879"
shishi = "#F0A986"
sodenkaracha = "#A0674B"
sohi = "#ED784A"
sora = "#58B2DC"
sumi = "#1C1C1C"
sumire = "#66327C"
sunezumi = "#787D7B"
suoh = "#8E354A"
suohkoh = "#A96360"
susutake = "#6E552F"
suzumecha = "#8F5A3C"
syojyohi = "#E83015"
taikoh = "#F8C3CD"
taisya = "#A36336"
tamago = "#F9BF45"
tamamorokoshi = "#E8B647"
terigaki = "#C46243"
tetsu = "#26453D"
tetsukon = "#261E47"
tetsuonando = "#255359"
tobi = "#724832"
tohoh = "#FFC408"
toki = "#EEA9A9"
tokigaracha = "#DB8E71"
tokiwa = "#1B813E"
tokusa = "#2D6D4B"
tonocha = "#985F2A"
tonocha2 = "#4F726C"
tonoko = "#D7B98E"
torinoko = "#DAC9A6"
tsutsuji = "#E03C8A"
tsuyukusa = "#2EA9DF"
uguisu = "#6C6A2D"
uguisucha = "#6C6024"
ukon = "#EFBB24"
umemurasaki = "#A8497A"
umenezumi = "#9E7A7A"
umezome = "#E9A368"
urayanagi = "#B5CAA0"
usu = "#B28FCE"
usuao = "#91B493"
usubeni = "#E87A90"
usugaki = "#ECB88A"
usuki = "#FAD689"
usukoh = "#EBB471"
veludo = "#096148"
wakatake = "#5DAC81"
wasurenagusa = "#7DB9DE"
yamabuki = "#FFB11B"
yamabukicha = "#D19826"
yanagicha = "#939650"
yanaginezumi = "#808F7C"
yanagisusutake = "#4A593D"
yanagizome = "#91AD70"

library = {
    "ai": {"color": "#0D5661", "label": "藍"},
    "aikobicha": {"color": "#4B4E2A", "label": "藍媚茶"},
    "aimirucha": {"color": "#0F4C3A", "label": "藍海松茶"},
    "ainezumi": {"color": "#566C73", "label": "藍鼠"},
    "aisumicha": {"color": "#373C38", "label": "藍墨茶"},
    "akabeni": {"color": "#CB4042", "label": "赤紅"},
    "akakoh": {"color": "#E3916E", "label": "赤香"},
    "akakuchiba": {"color": "#C78550", "label": "赤朽葉"},
    "akashirotsurubami": {"color": "#E1A679", "label": "赤白橡"},
    "ake": {"color": "#CC543A", "label": "緋"},
    "akebono": {"color": "#F19483", "label": "曙"},
    "aku": {"color": "#877F6C", "label": "灰汁"},
    "aokuchiba": {"color": "#ADA142", "label": "青朽葉"},
    "aomidori": {"color": "#00AA90", "label": "青緑"},
    "aoni": {"color": "#516E41", "label": "青丹"},
    "aonibi": {"color": "#535953", "label": "青鈍"},
    "aotake": {"color": "#00896C", "label": "青竹"},
    "araigaki": {"color": "#E79460", "label": "洗柿"},
    "araisyu": {"color": "#FB966E", "label": "洗朱"},
    "asagi": {"color": "#33A6B8", "label": "浅葱"},
    "ayame": {"color": "#6F3381", "label": "菖蒲"},
    "azuki": {"color": "#954A45", "label": "小豆"},
    "baikocha": {"color": "#89916B", "label": "梅幸茶"},
    "bengara": {"color": "#9A5034", "label": "弁柄"},
    "benifuji": {"color": "#B481BB", "label": "紅藤"},
    "benihi": {"color": "#F75C2F", "label": "紅緋"},
    "benihiwada": {"color": "#884C3A", "label": "紅檜皮"},
    "benikaba": {"color": "#B54434", "label": "紅樺"},
    "benikakehana": {"color": "#4E4F97", "label": "紅掛花"},
    "benikeshinezumi": {"color": "#52433D", "label": "紅消鼠"},
    "benimidori": {"color": "#7B90D2", "label": "紅碧"},
    "benitobi": {"color": "#994639", "label": "紅鳶"},
    "beniukon": {"color": "#E98B2A", "label": "紅鬱金"},
    "binrojizome": {"color": "#3A3226", "label": "檳榔子染"},
    "biwacha": {"color": "#B17844", "label": "枇杷茶"},
    "botan": {"color": "#C1328E", "label": "牡丹"},
    "budohnezumi": {"color": "#5E3D50", "label": "葡萄鼠"},
    "byakugun": {"color": "#78C2C4", "label": "白群"},
    "byakuroku": {"color": "#A8D8B9", "label": "白緑"},
    "chigusa": {"color": "#3A8FB7", "label": "千草"},
    "chitosemidori": {"color": "#36563C", "label": "千歳緑"},
    "chojicha": {"color": "#96632E", "label": "丁子茶"},
    "chojizome": {"color": "#B07736", "label": "丁子染"},
    "cyohsyun": {"color": "#BF6766", "label": "長春"},
    "dobunezumi": {"color": "#4F4F48", "label": "溝鼠"},
    "ebicha": {"color": "#734338", "label": "海老茶"},
    "ebizome": {"color": "#6D2E5B", "label": "蒲葡"},
    "edocha": {"color": "#AF5F3C", "label": "江戸茶"},
    "edomurasaki": {"color": "#77428D", "label": "江戸紫"},
    "enji": {"color": "#9F353A", "label": "燕脂"},
    "ensyucha": {"color": "#CA7853", "label": "遠州茶"},
    "entan": {"color": "#D75455", "label": "鉛丹"},
    "fuji": {"color": "#8B81C3", "label": "藤"},
    "fujimurasaki": {"color": "#8A6BBE", "label": "藤紫"},
    "fujinezumi": {"color": "#6E75A4", "label": "藤鼠"},
    "fujisusutake": {"color": "#574C57", "label": "藤煤竹"},
    "fukagawanezumi": {"color": "#77969A", "label": "深川鼠"},
    "fushizome": {"color": "#967249", "label": "柴染"},
    "futaai": {"color": "#70649A", "label": "二藍"},
    "ginnezumi": {"color": "#91989F", "label": "銀鼠"},
    "ginsusutake": {"color": "#82663A", "label": "銀煤竹"},
    "ginsyu": {"color": "#C73E3A", "label": "銀朱"},
    "gofun": {"color": "#FFFFFB", "label": "胡粉"},
    "gunjyo": {"color": "#51A8DD", "label": "群青"},
    "hai": {"color": "#828282", "label": "灰"},
    "haizakura": {"color": "#D7C4BB", "label": "灰桜"},
    "hajizome": {"color": "#DDA52D", "label": "櫨染"},
    "hanaasagi": {"color": "#1E88A8", "label": "花浅葱"},
    "hanaba": {"color": "#F7C242", "label": "花葉"},
    "hanada": {"color": "#006284", "label": "縹"},
    "hashita": {"color": "#986DB2", "label": "半"},
    "hatobanezumi": {"color": "#72636E", "label": "鳩羽鼠"},
    "higosusutake": {"color": "#8D742A", "label": "肥後煤竹"},
    "hiwa": {"color": "#BEC23F", "label": "鶸"},
    "hiwacha": {"color": "#A5A051", "label": "鶸茶"},
    "hiwada": {"color": "#854836", "label": "檜皮"},
    "hiwamoegi": {"color": "#90B44B", "label": "鶸萌黄"},
    "ichigo": {"color": "#B5495B", "label": "苺"},
    "ikkonzome": {"color": "#F4A7B9", "label": "一斥染"},
    "imayoh": {"color": "#D05A6E", "label": "今様"},
    "iwaicha": {"color": "#646A58", "label": "岩井茶"},
    "jinzamomi": {"color": "#EB7A77", "label": "甚三紅"},
    "kaba": {"color": "#C1693C", "label": "樺"},
    "kabacha": {"color": "#B35C37", "label": "樺茶"},
    "kachi": {"color": "#08192D", "label": "褐"},
    "kakishibu": {"color": "#A35E47", "label": "柿渋"},
    "kakitsubata": {"color": "#622954", "label": "杜若"},
    "kamenozoki": {"color": "#A5DEE4", "label": "瓶覗"},
    "kanzo": {"color": "#FC9F4D", "label": "萱草"},
    "karacha": {"color": "#B47157", "label": "唐茶"},
    "karakurenai": {"color": "#D0104C", "label": "韓紅花"},
    "karashi": {"color": "#CAAD5F", "label": "芥子"},
    "kariyasu": {"color": "#E9CD4C", "label": "刈安"},
    "kenpohzome": {"color": "#43341B", "label": "憲法染"},
    "keshizumi": {"color": "#434343", "label": "消炭"},
    "kigaracha": {"color": "#C18A26", "label": "黄唐茶"},
    "kihada": {"color": "#FBE251", "label": "黄蘗"},
    "kikuchiba": {"color": "#D9AB42", "label": "黄朽葉"},
    "kikujin": {"color": "#B1B479", "label": "麹塵"},
    "kikyo": {"color": "#6A4C9C", "label": "桔梗"},
    "kimirucha": {"color": "#867835", "label": "黄海松茶"},
    "kincha": {"color": "#C7802D", "label": "金茶"},
    "kitsune": {"color": "#9B6E23", "label": "狐"},
    "kitsurubami": {"color": "#BA9132", "label": "黄橡"},
    "kobicha": {"color": "#876633", "label": "媚茶"},
    "kogecha": {"color": "#563F2E", "label": "焦茶"},
    "kohaku": {"color": "#CA7A2C", "label": "琥珀"},
    "kohbai": {"color": "#E16B8C", "label": "紅梅"},
    "kohrozen": {"color": "#7D532C", "label": "黄櫨染"},
    "koke": {"color": "#838A2D", "label": "苔"},
    "kokiake": {"color": "#86473F", "label": "深緋"},
    "kokikuchinashi": {"color": "#FB9966", "label": "深支子"},
    "kokimurasaki": {"color": "#4A225D", "label": "深紫"},
    "kon": {"color": "#0F2540", "label": "紺"},
    "konjyo": {"color": "#113285", "label": "紺青"},
    "konkikyo": {"color": "#211E55", "label": "紺桔梗"},
    "korainando": {"color": "#305A56", "label": "高麗納戸"},
    "kuchiba": {"color": "#E2943B", "label": "朽葉"},
    "kuchinashi": {"color": "#F6C555", "label": "梔子"},
    "kurenai": {"color": "#CB1B45", "label": "紅"},
    "kurikawacha": {"color": "#6A4028", "label": "栗皮茶"},
    "kuriume": {"color": "#904840", "label": "栗梅"},
    "kuro": {"color": "#080808", "label": "黒"},
    "kurobeni": {"color": "#3F2B36", "label": "黒紅"},
    "kurotobi": {"color": "#554236", "label": "黒鳶"},
    "kurotsurubami": {"color": "#0B1013", "label": "黒橡"},
    "kurumi": {"color": "#947A6D", "label": "胡桃"},
    "kuwacha": {"color": "#C99833", "label": "桑茶"},
    "kuwazome": {"color": "#64363C", "label": "桑染"},
    "kyara": {"color": "#78552B", "label": "伽羅"},
    "masuhana": {"color": "#577C8A", "label": "舛花"},
    "matsuba": {"color": "#42602D", "label": "松葉"},
    "messhi": {"color": "#533D5B", "label": "滅紫"},
    "midori": {"color": "#227D51", "label": "緑"},
    "miru": {"color": "#5B622E", "label": "海松"},
    "mirucha": {"color": "#62592C", "label": "海松茶"},
    "mizu": {"color": "#81C7D4", "label": "水"},
    "mizuasagi": {"color": "#66BAB7", "label": "水浅葱"},
    "mizugaki": {"color": "#B9887D", "label": "水がき"},
    "moegi": {"color": "#7BA23F", "label": "萌黄"},
    "momo": {"color": "#F596AA", "label": "桃"},
    "momoshiocha": {"color": "#724938", "label": "百塩茶"},
    "murasaki": {"color": "#592C63", "label": "紫"},
    "murasakitobi": {"color": "#60373E", "label": "紫鳶"},
    "mushiao": {"color": "#20604F", "label": "虫襖"},
    "mushikuri": {"color": "#D9CD90", "label": "蒸栗"},
    "nadeshiko": {"color": "#DC9FB4", "label": "撫子"},
    "nae": {"color": "#86C166", "label": "苗"},
    "nakabeni": {"color": "#DB4D6D", "label": "中紅"},
    "namakabe": {"color": "#7D6C46", "label": "生壁"},
    "namari": {"color": "#787878", "label": "鉛"},
    "nanohana": {"color": "#F7D94C", "label": "菜の花"},
    "nasukon": {"color": "#572A3F", "label": "茄子紺"},
    "nataneyu": {"color": "#A28C37", "label": "菜種油"},
    "nibi": {"color": "#656765", "label": "鈍"},
    "nisemurasaki": {"color": "#562E37", "label": "似紫"},
    "noshimehana": {"color": "#2B5F75", "label": "熨斗目花"},
    "ohdo": {"color": "#B68E55", "label": "黄土"},
    "ohni": {"color": "#F05E1C", "label": "黄丹"},
    "oitake": {"color": "#6A8372", "label": "老竹"},
    "omeshicha": {"color": "#376B6D", "label": "御召茶"},
    "omeshionando": {"color": "#2E5C6E", "label": "御召御納戸"},
    "ominaeshi": {"color": "#DDD23B", "label": "女郎花"},
    "onando": {"color": "#0C4842", "label": "御納戸"},
    "onandocha": {"color": "#465D4C", "label": "御納戸茶"},
    "ouchi": {"color": "#9B90C2", "label": "楝"},
    "rikancha": {"color": "#616138", "label": "璃寛茶"},
    "rikyucha": {"color": "#897D55", "label": "利休茶"},
    "rikyunezumi": {"color": "#707C74", "label": "利休鼠"},
    "rikyushiracha": {"color": "#B4A582", "label": "利休白茶"},
    "ro": {"color": "#0C0C0C", "label": "呂"},
    "rokohcha": {"color": "#74673E", "label": "路考茶"},
    "rokusyoh": {"color": "#24936E", "label": "緑青"},
    "ruri": {"color": "#005CAF", "label": "瑠璃"},
    "rurikon": {"color": "#0B346E", "label": "瑠璃紺"},
    "sabiasagi": {"color": "#6699A1", "label": "錆浅葱"},
    "sabionando": {"color": "#336774", "label": "錆御納戸"},
    "sabiseiji": {"color": "#86A697", "label": "錆青磁"},
    "sabitetsuonando": {"color": "#405B55", "label": "錆鉄御納戸"},
    "sakura": {"color": "#FEDFE1", "label": "桜"},
    "sakuranezumi": {"color": "#B19693", "label": "桜鼠"},
    "sangosyu": {"color": "#F17C67", "label": "珊瑚朱"},
    "seiheki": {"color": "#268785", "label": "青碧"},
    "seiji": {"color": "#69B0AC", "label": "青磁"},
    "sencha": {"color": "#855B32", "label": "煎茶"},
    "sensaicha": {"color": "#4D5139", "label": "千歳茶"},
    "sharegaki": {"color": "#FFBA84", "label": "洒落柿"},
    "shikancha": {"color": "#B55D4C", "label": "芝翫茶"},
    "shikon": {"color": "#3C2F41", "label": "紫紺"},
    "shinbashi": {"color": "#0089A7", "label": "新橋"},
    "shinsyu": {"color": "#AB3B3A", "label": "真朱"},
    "shion": {"color": "#8F77B5", "label": "紫苑"},
    "shiracha": {"color": "#BC9F77", "label": "白茶"},
    "shironeri": {"color": "#FCFAF2", "label": "白練"},
    "shironezumi": {"color": "#BDC0BA", "label": "白鼠"},
    "shirotsurubami": {"color": "#DCB879", "label": "白橡"},
    "shishi": {"color": "#F0A986", "label": "宍"},
    "sodenkaracha": {"color": "#A0674B", "label": "宗伝唐茶"},
    "sohi": {"color": "#ED784A", "label": "纁"},
    "sora": {"color": "#58B2DC", "label": "空"},
    "sumi": {"color": "#1C1C1C", "label": "墨"},
    "sumire": {"color": "#66327C", "label": "菫"},
    "sunezumi": {"color": "#787D7B", "label": "素鼠"},
    "suoh": {"color": "#8E354A", "label": "蘇芳"},
    "suohkoh": {"color": "#A96360", "label": "蘇芳香"},
    "susutake": {"color": "#6E552F", "label": "煤竹"},
    "suzumecha": {"color": "#8F5A3C", "label": "雀茶"},
    "syojyohi": {"color": "#E83015", "label": "猩猩緋"},
    "taikoh": {"color": "#F8C3CD", "label": "退紅"},
    "taisya": {"color": "#A36336", "label": "代赭"},
    "tamago": {"color": "#F9BF45", "label": "玉子"},
    "tamamorokoshi": {"color": "#E8B647", "label": "玉蜀黍"},
    "terigaki": {"color": "#C46243", "label": "照柿"},
    "tetsu": {"color": "#26453D", "label": "鉄"},
    "tetsukon": {"color": "#261E47", "label": "鉄紺"},
    "tetsuonando": {"color": "#255359", "label": "鉄御納戸"},
    "tobi": {"color": "#724832", "label": "鳶"},
    "tohoh": {"color": "#FFC408", "label": "籐黄"},
    "toki": {"color": "#EEA9A9", "label": "鴇"},
    "tokigaracha": {"color": "#DB8E71", "label": "ときがら茶"},
    "tokiwa": {"color": "#1B813E", "label": "常磐"},
    "tokusa": {"color": "#2D6D4B", "label": "木賊"},
    "tonocha": {"color": "#985F2A", "label": "礪茶"},
    "tonocha2": {"color": "#4F726C", "label": "沈香茶"},
    "tonoko": {"color": "#D7B98E", "label": "砥粉"},
    "torinoko": {"color": "#DAC9A6", "label": "鳥の子"},
    "tsutsuji": {"color": "#E03C8A", "label": "躑躅"},
    "tsuyukusa": {"color": "#2EA9DF", "label": "露草"},
    "uguisu": {"color": "#6C6A2D", "label": "鶯"},
    "uguisucha": {"color": "#6C6024", "label": "鶯茶"},
    "ukon": {"color": "#EFBB24", "label": "鬱金"},
    "umemurasaki": {"color": "#A8497A", "label": "梅紫"},
    "umenezumi": {"color": "#9E7A7A", "label": "梅鼠"},
    "umezome": {"color": "#E9A368", "label": "梅染"},
    "urayanagi": {"color": "#B5CAA0", "label": "裏柳"},
    "usu": {"color": "#B28FCE", "label": "薄"},
    "usuao": {"color": "#91B493", "label": "薄青"},
    "usubeni": {"color": "#E87A90", "label": "薄紅"},
    "usugaki": {"color": "#ECB88A", "label": "薄柿"},
    "usuki": {"color": "#FAD689", "label": "浅黄"},
    "usukoh": {"color": "#EBB471", "label": "薄香"},
    "veludo": {"color": "#096148", "label": "ビロード"},
    "wakatake": {"color": "#5DAC81", "label": "若竹"},
    "wasurenagusa": {"color": "#7DB9DE", "label": "勿忘草"},
    "yamabuki": {"color": "#FFB11B", "label": "山吹"},
    "yamabukicha": {"color": "#D19826", "label": "山吹茶"},
    "yanagicha": {"color": "#939650", "label": "柳茶"},
    "yanaginezumi": {"color": "#808F7C", "label": "柳鼠"},
    "yanagisusutake": {"color": "#4A593D", "label": "柳煤竹"},
    "yanagizome": {"color": "#91AD70", "label": "柳染"},
}
